﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hacker : MonoBehaviour
{
    //Game State
    int level;

    enum Screen { MainMenu, Password, Win}
    Screen currentScreen = Screen.MainMenu;

    // Start is called before the first frame update
    void Start()
    {
        ShowStartMenu();
    }
    
    void ShowStartMenu()
    {
        var greeting = "Hello Abhishek";
        currentScreen = Screen.MainMenu;
        Terminal.ClearScreen();
        Terminal.WriteLine(greeting);
        Terminal.WriteLine("What would you like to hack into?");
        Terminal.WriteLine("Press 1 for Local");
        Terminal.WriteLine("Press 2 for Police Sation");
        Terminal.WriteLine("Enter your choice");
    }

    void OnUserInput(string input)
    {
        if (input == "menu")
        {
            ShowStartMenu();
        }
        else if (currentScreen == Screen.MainMenu)
        {
            RunMainMenu(input);
        }
        else if(currentScreen == Screen.Password)
        {
            Password(input);
        }
    }
    void RunMainMenu(string input)
    {
        if (input == "1")
        {
            StartGame(1);
            level = 1;
        }
        else if (input == "2")
        {
            StartGame(2);
            level = 2;
        }
        else
        {
            Terminal.WriteLine("The user typed " + input);
        }
    }

    void StartGame(int level)
    {
        currentScreen = Screen.Password;
        Terminal.WriteLine("You have chosen level " + level);
        Terminal.WriteLine("Please give me a password");
    }

    void Password(string input)
    {
        string password0 = "donkey";
        string password1 = "monkey";
        if(input==password0 && level == 1 || level == 2 && input == password1)
        {
            Terminal.WriteLine("Well done");
        }
        else
        {
            Terminal.WriteLine("Bhaag Bhosadike");
        }
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
